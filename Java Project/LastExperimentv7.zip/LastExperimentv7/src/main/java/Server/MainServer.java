package Server;

public class MainServer {
    public static void main(String[] args)
    {
        new Server();
    }
}
