package Server;

public class MainClient {
    public static void main(String[] args)
    {
        new Client("172.18.2.180");
    }
}
