/*
Student: Aziz Latipov
ID:U2110185
 */

import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

public class Serverr{//Class server
    private ServerSocket serverSocket;//Server socket data field of the server class
    float weight,height;//User's height and weight

    public Serverr(ServerSocket serverSocket) throws UnknownHostException {
        this.serverSocket=serverSocket;//setting serversocket to class' server socket
        System.out.println("Server IP: " + InetAddress.getLocalHost().getHostAddress());//printing ip address
        System.out.println("Waiting for the client request");//just a general output
    }

    public void runServer(){//Function to start/run the server
        try{
            Socket socket = serverSocket.accept();//waiting for client's connection
            System.out.println("A new user has joined");//general output
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());//initializing object input stream to read from user
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());//initializing object output stream to write to user
            while (!serverSocket.isClosed()){//while loop to constantly read and write to/from user
                height = (Float)objectInputStream.readObject();//read height, as it is always given first
                weight = (Float)objectInputStream.readObject();//read weight, as it is always given second
                objectOutputStream.writeObject(BMI_Calc());//sending the result of BMI_Calc() function to the client
            }
        } catch (IOException e) {//catch clause if there is an error has occured
            CloseEverything();//calling a CloseEverything function
        } catch (ClassNotFoundException e) {//catch clause if there is an error has occured(OIS and OOS)
            throw new RuntimeException(e);//Throwing an error
        }
    }
    public void CloseEverything(){//Function for safe close
        if (serverSocket != null) {//when serverSocket is set
            try {
                serverSocket.close();//closes the serverSocket
            } catch (IOException e) {//in case of the occured errros
                throw new RuntimeException(e);//throws an error
            }
        }
    }
    public float BMI_Calc(){//bmi calculator function
        return weight/height/height;
    }



    public static void main(String args[]) throws IOException {
        ServerSocket serverSocket = new ServerSocket(6969);//initializing and setting a port of a ServerSocket
        Serverr server = new Serverr(serverSocket);//Creating a Server class object
        server.runServer();//Calling a runServer function
    }
}