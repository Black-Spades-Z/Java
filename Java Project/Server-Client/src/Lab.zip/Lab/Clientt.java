/*
Student: Aziz Latipov
ID:U2110185
 */
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Clientt {
    //all the client's data fields that will be needed throughout the program
    Socket socket = null;
    float height;
    float weight;
    Scanner in = new Scanner(System.in);
    ObjectInputStream objectInputStream = null;
    ObjectOutputStream objectOutputStream=null;

    public Clientt(Socket soc) {//constructor
        try {
            this.socket = soc;//setting socket to given parameter

            objectOutputStream = new ObjectOutputStream(socket.getOutputStream());//creating an objectoutputstream instance of the given socket
            objectInputStream = new ObjectInputStream(socket.getInputStream());//creating an objectinputstream instance of the given socket

        } catch (IOException e) {
            CloseEverything(socket, objectOutputStream, objectInputStream);//in case of an error safe close of the program
        }
    }

    public void SendMessage() {//function to send object to the server
        try {
            int ch;//choice instance to read user's choice
            while (socket.isConnected()) {//loop that will not halt
                System.out.println("~~~MENU~~~\n" +
                        "1. Set Weight\n" +
                        "2. Set Height\n" +
                        "3. Send to Server\n" +
                        "4. EXIT");//general output
                System.out.print("CHOICE: ");
                ch=in.nextInt();//reading user's choice
                switch (ch) {
                    case 1://if user has chosen 1 option
                        System.out.println("Insert Weight:");
                        weight = in.nextFloat();
                        break;
                    case 2://if user has chosen 2 option
                        System.out.println("Insert height:");
                        height = in.nextFloat();
                        break;
                    case 3://if user has chosen 3 option
                        if (height == 0 || weight == 0) {
                            System.out.println("You have not set height and weight yet!");
                            break;
                        } else {
                            objectOutputStream.writeObject(height);
                            objectOutputStream.writeObject(weight);
                            System.out.println("Your BMI: " + ((Float) objectInputStream.readObject()));
                            break;
                        }
                    case 4://if user has chosen 4 option
                        System.out.print("Thank you for choosing us");
                        return;
                }
            }

        } catch (IOException e) {
            CloseEverything(socket, objectOutputStream, objectInputStream);//safe close in case of the occured errors
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);//throws an error
        }
    }

    private void CloseEverything(Socket socket, ObjectOutputStream objectOutputStream, ObjectInputStream objectInputStream) {//safe close function
        try {
            //checks whether if all OIS and OOS are not null so that it can close them all properly and only necessary ones
            if(objectInputStream!=null)
                objectInputStream.close();
            if(objectOutputStream!=null)
                objectOutputStream.close();
            if(socket!=null)
                socket.close();
        }
        catch (IOException e){//in case of errors
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException{
        //Reading server's IP
        System.out.print("IP: ");
        Scanner in = new Scanner(System.in);
        Socket socket;
        //establish socket connection to server
        socket = new Socket(in.nextLine(), 6969);
        Clientt client = new Clientt(socket);//Creating an instance of clientt class
        client.SendMessage();//calling a send message function
    }
}
