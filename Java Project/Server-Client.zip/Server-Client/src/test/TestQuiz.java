package test;

class MidtermTestClass{
    String str;
    int i;
    boolean b;
    double testMethod(int a){
        return 2.0*2.0;
    }

}





public class TestQuiz {
}
